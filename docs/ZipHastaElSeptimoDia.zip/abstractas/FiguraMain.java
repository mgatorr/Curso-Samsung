package abstractas;

import upm.jbb.IO;

public class FiguraMain {

	public static void main(String[] args) {
		IO.in.addController(new FiguraMain());
		


	}

}
