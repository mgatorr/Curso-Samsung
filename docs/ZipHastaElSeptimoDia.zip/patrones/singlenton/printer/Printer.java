package patrones.singlenton.printer;

public interface Printer {
	void print(String msg);
}
