package test;

public class ContadorCircular {
	private int contador;

	public int getContador() {
		return contador;
	}

	/*private void setContador(int contador) {
		this.contador = contador;
	}*/

	public ContadorCircular() {

	}

	public ContadorCircular(int cont) {

	}

	public void inicializarContador() {

	}

	public void sumarContador() {

	}

	public void restarContador() {

	}

}
