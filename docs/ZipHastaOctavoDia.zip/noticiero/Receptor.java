package noticiero;

public interface Receptor {

	public void noticia(String texto);
}
