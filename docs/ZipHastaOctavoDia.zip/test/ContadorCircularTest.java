package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContadorCircularTest {

	@Test
	public void testContadorCircular() {
		
	}

	@Test
	public void testContadorCircularInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testInicializarContador() {
		fail("Not yet implemented");
	}

	@Test
	public void testSumarContador() {
		fail("Not yet implemented");
	}

	@Test
	public void testRestarContador() {
		fail("Not yet implemented");
	}

}
