package patrones.factory;

public abstract class Producto {
	public abstract void view();
}