package patrones.factory;

public abstract class Creador {
	public abstract Producto crearProducto();
}