package patrones.state.conexionred;

public enum Estado {
	PARADO,CERRADO,PREPARADO;
}
