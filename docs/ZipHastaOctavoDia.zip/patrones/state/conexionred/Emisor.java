package patrones.state.conexionred;

public interface Emisor {
	void enviar(String msg);
}