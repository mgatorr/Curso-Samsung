package patrones.state;

public abstract class State {
	public abstract void action1(Context context);

	public abstract void action2(Context context);
}