package patrones.factory.numeros;

public abstract class CreadorNumero {
	public abstract Numero createNumero();

}
