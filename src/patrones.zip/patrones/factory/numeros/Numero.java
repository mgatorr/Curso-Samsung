package patrones.factory.numeros;

public abstract class Numero {

	public abstract String convertir(int numero);

}
